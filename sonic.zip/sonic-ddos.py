import os,sys,time,re,requests,json
from requests import post

print('METHOD : GET/POST/HEAD')

url = input("[>] URL : ")
port = input("[>] PORT : ")
thr = input("[>] THREADS : ")
method = input("[>] METHODS : ")

os.system('python doseq.py -s' + url + '-p' + port + '-t' + thr + '-a' + method)